import React from "react";
import styled from "styled-components";


const Ex = styled.h1`
    font-size: 50px;
    font-weight: bold;`;



function SignUpPage(props) {
    return (
        <div>
            <Ex>SignUpPage</Ex>
        </div>
    );
}

export default SignUpPage;