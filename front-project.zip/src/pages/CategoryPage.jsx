import React from "react";
import Header from "../components/common/Header";

function CategoryPage(props) {
    return (
        <div>
            <Header />
            <h1>Category Page</h1>
        </div>
    );
}

export default CategoryPage;