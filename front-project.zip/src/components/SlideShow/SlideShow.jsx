import React from 'react';
import Slider from 'react-slick';
import styled from 'styled-components';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import data from "../../data.json";

const Wrapper = styled.div `
    width: calc(100% - 50px);
    max-width: 1200px;
    margin: 0 auto; // 가로 중앙 정렬을 위해 추가
    padding: 50px 0; // 상하 패딩을 추가하여 세로 중앙에 더 가깝게
`;

const SlideItem = styled.div `
    width: calc(25% - 20px);
    display: flex;
    justify-content: center; // 가로 중앙 정렬
    align-items: center; // 세로 중앙 정렬
    height: 300px; // 슬라이드의 높이 조정이 필요하면 수정하세요.
    overflow: hidden;
    margin: 0;

    img {
        width: 100%;
        height: 100%;
        object-fit: contain; // 이미지가 슬라이드의 높이보다 클 경우 이미지의 비율을 유지하도록 조정
        margin: 0 50px;
    }
`;

const SlideShow = () => {
    const navigate = useNavigate();
    const [isDragging, setIsDragging] = useState(false);

    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 6,
        autoplay: true,
        autoplaySpeed: 2000,
        beforeChange: () => setIsDragging(true),
        afterChange: () => setIsDragging(false)
    };

    const images = data.flatMap(category => category.items.map(item => item.details));

    // 이미지 클릭 이벤트 핸들러
    const handleImageClick = (id) => {
        if (!isDragging) {
            navigate(`/detail/${id}`);
        }
    };

    return (
        <Wrapper>
            <Slider {...settings}>
                {images.map((image) => (
                    <SlideItem key={image.id} onClick={() => handleImageClick(image.id)}>
                        <img src={image.src} alt={image.alt} />
                    </SlideItem>
                ))}
            </Slider>
        </Wrapper>
    );
}

export default SlideShow;