import React from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from './SearchBar';
import styled from 'styled-components';

const HeaderWrapper = styled.header `
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    background-color: #f8f8f8;
`;

const Logo = styled.div `
    font-size: 1.5rem;
    color: grey;
    font-weight: bold;
    cursor: pointer;
`;

const LoginButton = styled.button `
    background-color: #fff;
    border: 1px solid #dcdcdc;
    padding: 0.5rem 1rem;
    cursor: pointer;
`;

function Header() {
    const navigate = useNavigate();

    const moveMainPage = () => {
        navigate('/');
    }

    return (
        <HeaderWrapper>
            <Logo onClick={moveMainPage}>로고</Logo>
            <SearchBar/>
            <LoginButton onClick={() => navigate('/signup')}>로그인</LoginButton>
        </HeaderWrapper>
    );
}

export default Header;