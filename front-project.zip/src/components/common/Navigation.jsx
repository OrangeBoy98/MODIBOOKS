import React from 'react';
import { Link } from 'react-router-dom';
import styled from 'styled-components';

const NavWrapper = styled.nav`
    display: flex;
    justify-content: flex-end; // 오른쪽 정렬
    gap: 20px; // 링크 사이의 간격
    padding: 1rem; // 여백 추가
`;

function Navigation() {
    return (
        <NavWrapper>
            <Link to="/category">카테고리</Link>
            <Link to="/services">고객센터</Link>
            <Link to="/contact">이름없음</Link>
        </NavWrapper>
    );
}

export default Navigation;